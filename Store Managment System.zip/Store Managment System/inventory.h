#ifndef _INVENTORY_H
#define _INVENTORY_H
//***************************************************************************
/*The Project on Inventory Management System comprises of different classes 
* The classes have their setter, getter function among constructor and destructors
* Here we are using file handling.*/
//***************************************************************************

#include<iostream>
#include <iomanip>
#include <fstream>
#include<string.h>
#include <conio.h>

//Store class has constructor, destructor, setter and getter function
//By using file handling, we can access each item stored in store file 
//It will remove, add, update and search function

class Store
{
public:
	char productname[26];
	int barcode;
	float price;
	int quantity;
	int elecricitybill;
	int shopebill;
	int total;

	Store();
	void file();
	int getFirstBlank();
	void setdata(char, int, float, int);
	int getdata()const;
	void add();
	void update();
	void remove();
	void search();
	void print();
	~Store();
};

//Customer class has constructor, destructor, setter and getter function
//By using file handling, we can access each item stored in customer file 
//It will buy and show products from store

class customer
{
private:
	Store* s;
public:

	customer(Store* st)
	{

		s = st;

	}
	void showproduct();
	void buy();
	void addition();
	void setdata(char, int, float, int);
	int getdata()const;
	int getFirstBlank();
	void file();
	~customer();
};

//Person class has constructor, destructor, setter and getter function
// it will store id of person in new file

class Person
{
public:
	int id;
	Person();

	void setdata(int);
	int getdata()const;
	~Person();
};

// The Employee class inherit data from Person class 
// By using file handling we can add salary and name of employee inherit from person

class Employee :public Person
{
public:
	int id;
	float salary;
	char name;

	Employee();
	void file();
	int getFirstBlank();
	void setdata(char, int, float);
	int getdata()const;
	void add();
	void update();
	void print();
	void removeemployee();
	void search();
	~Employee();
};

//The Dealer inherit its information from person class which store data in file
//it will store data rrequire for store

class Dealer :public Person
{
public:
	int quantity;
		int price;
		char productname;
		int barcode;

	Dealer();
	void file();
	int getFirstBlank();
	void setdata(char,int,int,int);
	int getdata()const;
	int add();
	void update();
	void print();
	~Dealer();
};

//Rent Class store bills

class Rent
{
private:
	Store* sto;
public:

	Rent(Store* str)
	{

		sto = str;

	}


public:

	char productname;
	int elecricitybill;
	int shopebill;
	int total;
	Rent();
	void file();
	int getFirstBlank();
	void setdata(char, int, int, int);
	int getdata()const;
	void add();
	void search();
	void print();
	~Rent();
};

//Warehouse class has access with Rent class which store information of rent class

class Warhouse :public Rent
{

public:
	
	int billid;
	int billcustomer;
	char billtype;
	Warhouse();
	void file();
	int getFirstBlank();
	void setdata(int, int, char);
	int getdata()const;

	~Warhouse();
};

#endif
