//***************************************************************************
// Code By: Group B
//Function definitions
// IMGS
//***************************************************************************

#include<iostream>
#include "inventory.h"
#include <math.h>
#include <iomanip>
#include <fstream>
#include<string.h>
#include <conio.h>
using namespace std;

Store::Store() //default
{
	productname[26] = ' ';
	barcode = 0;
	price = 0;
	quantity = 0;
}
//for spacing
int Store::getFirstBlank()
{
	char data[50];
	ifstream fin("Store.txt");
	int id = 1;
	while (!fin.eof())
	{
		fin.getline(data, 48);
		if (strncmp(&data[5], "                         ", 25) == 0)
		{
			return id;
		}
		else
		{
			id++;
		}

	}
	fin.close();

}
void Store::search()
{
	char searchstring[25];
	cin.ignore();
	cout << "Please enter your search string: ";
	cin.getline(searchstring, 25);


	char data[50];
	ifstream fin("Store.txt");
	cout << "--------------------------------------------" << endl;
	cout << "id" << "   Productname" << "              Price" << "Quan " << "Total" << endl;
	cout << "--------------------------------------------" << endl;

	while (!fin.eof())
	{
		fin.getline(data, 48);
		if (strncmp(&data[5], searchstring, strlen(searchstring)) == 0)
		{
			cout << data << endl;
		}

	}
	cout << "--------------------------------------------" << endl;
	fin.close();
}
//access from file
void Store::file()
{
	fstream new_file;
	new_file.open("Store.txt", ios::out);
	if (!new_file)
	{
		cout << "File creation failed";
	}
	else
	{
		new_file << "--------------------------------------------" << endl;
		new_file << "id" << "   Productname" << "              Price" << "Quan " << "Total" << endl;
		new_file << "--------------------------------------------" << endl;   //Writing to file
		for (int i = 1; i <= 10; i++)
		{
			new_file << left << setw(5) << i;
			new_file << left << setw(25) << "";
			new_file << left << setw(5) << 0;
			new_file << left << setw(5) << 0;
			new_file << left << setw(5) << 0 << endl;
		}
		new_file << "--------------------------------------------" << endl;
		new_file.close();
	}




}
void Store::add()
{
	int newid = getFirstBlank();

	//char productname[26];
	cin.ignore();
	/*cout << "Please enter the product name:";
	cin.getline(productname, 25);
	cout << "Please enter the quantity:";
	cin >> quantity;
	cout << "Please enter the per unit price :";
	cin >> price;*/
	barcode = price * quantity;
	fstream f("Store.txt", ios::out | ios::in);
	f.seekp(47 * (newid - 1) + 3);
	f << left << setw(25) << productname;

	f.seekp(47 * (newid - 1) + 28);
	f << left << setw(5) << quantity;

	f.seekp(47 * (newid - 1) + 33);
	f << left << setw(5) << price;
	f.seekp(47 * (newid - 1) + 38);
	f << left << setw(5) << barcode;

	f.close();


	//	system("pause");
	system("cls");

}
void Store::print()
{
	char data[50];
	ifstream fin("Store.txt");

	while (!fin.eof())
	{
		fin.getline(data, 48);
		if (strncmp(&data[5], "                         ", 25) != 0)
		{
			cout << data << endl;
		}

	}
	fin.close();
}
void Store::setdata(char pn, int bc, float p, int q)
{
	productname[26] = pn;
	barcode = bc;
	price = p;
	quantity = q;
}
void Store::update()
{
	int id, newquantity, newprice, barcode;
	char productname[25];

	cout << "Please enter the id of the product you want to edit:";
	cin >> id;
	cout << "Please enter the new name of the product: ";
	cin.ignore();
	cin.getline(productname, 25);
	cout << "Pleae enter the new quantity of the product:";
	cin >> newquantity;
	cout << "Pleae enter the new per unit price of the product:";
	cin >> newprice;
	barcode = newprice * newquantity;

	fstream f("Store.txt", ios::in | ios::out);

	f.seekp(47 * (id + 2) + 3);
	f << left << setw(25) << productname;

	f.seekp(47 * (id + 2) + 28);
	f << left << setw(5) << newquantity;

	f.seekp(47 * (id + 2) + 33);
	f << left << setw(5) << newprice;
	f.seekp(47 * (id + 2) + 38);
	f << left << setw(5) << barcode;


	f.close();

	cout << "Record updated successfully. " << endl;
}
void Store::remove()
{
	int id;


	cout << "Please enter the id of the store you want to delete:";
	cin >> id;


	fstream f("Store.txt", ios::in | ios::out);

	f.seekp(47 * (id + 2) + 3);
	f << left << setw(25) << "";

	f.seekp(47 * (id + 2) + 28);
	f << left << setw(5) << 0;

	f.seekp(47 * (id + 2) + 33);
	f << left << setw(5) << 0;
	f.seekp(47 * (id + 2) + 38);
	f << left << setw(5) << 0;


	f.close();

	cout << "Record deleted successfully. " << endl;
}
int Store::getdata()const
{
	return productname, barcode, price, quantity;

}
Store::~Store()
{

}

void customer::file()
{


	fstream new_file;
	new_file.open("Customer.txt", ios::out);
	if (!new_file)
	{
		cout << "File creation failed";
	}
	else
	{
		new_file << "--------------------------------------------" << endl;
		new_file << "id" << "   Productname" << "              Price" << "Quan " << "Total" << endl;
		new_file << "--------------------------------------------" << endl;   //Writing to file
		for (int i = 1; i <= 10; i++)
		{
			new_file << left << setw(5) << i;
			new_file << left << setw(25) << "";
			new_file << left << setw(5) << 0;
			new_file << left << setw(5) << 0;
			new_file << left << setw(5) << 0 << endl;
		}
		new_file << "--------------------------------------------" << endl;
		new_file.close();

	}

}
void customer::showproduct()
{
	char data[50];
	ifstream fin("Customer.txt");

	while (!fin.eof())
	{
		fin.getline(data, 48);
		if (strncmp(&data[5], "                         ", 25) != 0)
		{
			cout << data << endl;
		}

	}
	fin.close();
}
int customer::getFirstBlank()
{
	char data[50];
	ifstream fin("Customer.txt");
	int id = 1;
	while (!fin.eof())
	{
		fin.getline(data, 48);
		if (strncmp(&data[5], "                         ", 25) == 0)
		{
			return id;
		}
		else
		{
			id++;
		}

	}
	fin.close();

}
void customer::addition()
{
	int newid = getFirstBlank();

	//char productname[26];
	cin.ignore();
	cout << "Please enter the product name:";
	cin>>s->productname;
	cin.ignore();
	cout << "Please enter the quantity:";
	cin >> s->quantity;
	cout << "Please enter the per unit price :";
	cin >> s->price;
	s->barcode = s->price * s->quantity;
	fstream f("Customer.txt", ios::out | ios::in);
	f.seekp(47 * (newid - 1) + 3);
	f << left << setw(25) <<s-> productname;

	f.seekp(47 * (newid - 1) + 28);
	f << left << setw(5) << s->quantity;

	f.seekp(47 * (newid - 1) + 33);
	f << left << setw(5) << s->price;
	f.seekp(47 * (newid - 1) + 38);
	f << left << setw(5) << s->barcode;
	s->add();

	f.close();


	//system("pause");
	system("cls");

}
void customer::buy()
{


	customer c(new Store());
	int id, oldqty, newqty, oldpr, oldbr, productname;
	cin.ignore();
	cout << "Please enter the id of the product you want to buy:";
	cin >> id;
		id = id + 3;
	cout << "Pleae enter the number of quantity:";
	cin >> newqty;

	fstream f("Customer.txt", ios::in | ios::out);
	fstream s("Store.txt", ios::in | ios::out);

	f.seekg(47 * (id - 1) + 28);
	f >> oldqty;
	f.seekp(47 * (id - 1) + 28);
	f << left << setw(5) << newqty;
	f.seekg(47 * (id - 1) + 33);
	f >> oldpr;

	f.seekg(47 * (id - 1) + 38);
	f >> oldbr;
	oldbr = (oldpr * newqty);
	f.seekp(47 * (id - 1) + 38);
	f << left << setw(5) << oldbr;
	s.seekg(47 * (id - 1) + 28);
	s >> oldqty;
	s.seekp(47 * (id - 1) + 28);
	newqty = oldqty - newqty;
	s << left << setw(5) << newqty;
	s.seekg(47 * (id - 1) + 33);
	s >> oldpr;
	s.seekg(47 * (id - 1) + 38);
	s >> oldbr;
	oldbr = (oldpr * newqty);
	s.seekp(47 * (id - 1) + 38);
	s << left << setw(5) << oldbr;


	s.close();
	f.close();

	cout << "Record updated successfully. " << endl;


}
customer::~customer()
{

}

Person::Person()
{

	id = 0;

}
Person::~Person()
{

}
void Person::setdata(int i)
{
	id = i;


}
int Person::getdata()const
{
	return id;

}

Employee::Employee()
{
	name = ' ';
	id = 0;
	salary = 0;

}
int Employee::getdata()const
{
	return name, id, salary;

}
Employee::~Employee()
{

}
void Employee::setdata(char n, int i, float s)
{
	name = n;
	id = i;
	salary = s;

}
int Employee::getFirstBlank()
{
	char data[45];
	ifstream fin("Employee.txt");
	int id = 1;
	while (!fin.eof())
	{
		fin.getline(data, 39);
		if (strncmp(&data[5], "                         ", 25) == 0)
		{
			return id;
		}
		else
		{
			id++;
		}

	}
	fin.close();

}
void Employee::file()
{
	fstream new_file;
	new_file.open("Employee.txt", ios::out);
	if (!new_file)
	{
		cout << "File creation failed";
	}
	else
	{
		new_file << "-----------------------------------" << endl;
		new_file << "id" << "  Name" << "                     Salary" << endl;    //Writing to file
		new_file << "-----------------------------------" << endl;
		for (int i = 1; i <= 10; i++)
		{
			new_file << left << setw(5) << i;
			new_file << left << setw(25) << "";
			new_file << left << setw(5) << 0 << endl;

		}
		new_file << "-----------------------------------" << endl;
		new_file.close();
	}




}
void Employee::add()
{
	int newid = getFirstBlank();

	char name[26];
	cin.ignore();
	cout << "Please enter the Name:";
	cin.getline(name, 25);
	cout << "Please enter the salary:";
	cin >> salary;


	fstream f("Employee.txt", ios::out | ios::in);
	f.seekp(37 * (newid - 1) + 4);
	f << left << setw(25) << name;

	f.seekp(37 * (newid - 1) + 29);
	f << left << setw(5) << salary;



	f.close();


	system("pause");
	system("cls");

}
void Employee::print()
{
	char data[40];
	ifstream fin("Employee.txt");

	while (!fin.eof())
	{
		fin.getline(data, 39);
		if (strncmp(&data[5], "                        ", 24) != 0)
		{
			cout << data << endl;
		}

	}
	fin.close();
}
void Employee::search()
{
	char name[25];
	cin.ignore();
	cout << "Please enter your search string: ";
	cin.getline(name, 25);


	char data[40];
	ifstream fin("Employee.txt");
	cout << "-----------------------------------" << endl;
	cout << "id" << "  Name" << "                     Salary" << endl;
	cout << "-----------------------------------" << endl;
	while (!fin.eof())
	{
		fin.getline(data, 39);
		if (strncmp(&data[4], name, strlen(name)) == 0)
		{
			cout << data << endl;
		}

	}
	cout << "-----------------------------------" << endl;
	fin.close();
}
void Employee::update()
{
	int id, newsalary;
	char name[25];

	cout << "Please enter the id of the Employee you want to edit:";
	cin >> id;
	cout << "Please enter the new name of the Employee: ";
	cin.ignore();
	cin.getline(name, 25);
	cout << "Pleae enter the new salary of the Employee:";
	cin >> newsalary;


	fstream f("Employee.txt", ios::in | ios::out);

	f.seekp(37 * (id + 2) + 4);
	f << left << setw(25) << name;

	f.seekp(37 * (id + 2) + 29);
	f << left << setw(5) << newsalary;



	f.close();

	cout << "Record updated successfully. " << endl;
}
void Employee::removeemployee()
{
	int id;


	cout << "Please enter the id of the Employee you want to delete:";
	cin >> id;


	fstream f("Employee.txt", ios::in | ios::out);

	f.seekp(37 * (id + 2) + 4);
	f << left << setw(25) << "";

	f.seekp(37 * (id + 2) + 29);
	f << left << setw(5) << 0;


	f.close();

	cout << "Record deleted successfully. " << endl;
}

Dealer::Dealer()
{
	 quantity = 0;
		 price = 0;
		 productname = ' ';
		 barcode = 0;
	
}
int Dealer::getFirstBlank()
{
		char data[50];
	ifstream fin("Dealer.txt");
	int id = 1;
	while (!fin.eof())
	{
		fin.getline(data, 48);
		if (strncmp(&data[5], "                         ", 25) == 0)
		{
			return id;
		}
		else
		{
			id++;
		}

	}
	fin.close();
	
}
void Dealer::file()
{
fstream new_file; 
new_file.open("Dealer.txt",ios::out);  
if(!new_file) 
{
cout<<"File creation failed";
}
else
{
new_file<<"--------------------------------------------"<<endl;
new_file<<"id"<<"   Productname"<<"              Price"<<"Quan "<<"Total"<<endl; 
new_file<<"--------------------------------------------"<<endl;   //Writing to file
for (int i = 1; i <= 10; i++)
	{
		new_file << left << setw(5) << i;
		new_file << left << setw(25) << "";
		new_file << left << setw(5) << 0;
		new_file << left << setw(5) << 0 ;
		new_file << left << setw(5) << 0 << endl;
	}
	new_file<<"--------------------------------------------"<<endl;
new_file.close(); 
}   

	

	
}
int Dealer::add()
{
	int newid = getFirstBlank();

	char productname[26];
	cin.ignore();
	cout << "Please enter the product name:";
	cin>>productname;
	cout << "Please enter the quantity:";
	cin >> quantity;
	cout << "Please enter the per unit price :";
	cin >> price;
	barcode=price * quantity;
	fstream f("Dealer.txt", ios::out | ios::in);
	f.seekp(47 * (newid - 1) + 3);
	f << left << setw(25) << productname;

	f.seekp(47 * (newid - 1) + 28);
	f << left << setw(5) << quantity;

	f.seekp(47 * (newid - 1) + 33);
	f << left << setw(5) << price;
	f.seekp(47 * (newid - 1) + 38);
	f << left << setw(5) << barcode;

	f.close();


//	system("pause");
	system("cls");

}
void Dealer::print()
{
	char data[50];
	ifstream fin("Dealer.txt");
	
	while (!fin.eof())
	{
		fin.getline(data, 48);
		if (strncmp(&data[5], "                         ", 25) != 0)
		{
			cout << data << endl;
		}

	}
	fin.close();
}
void Dealer::setdata(char pn,int q,int p,int b)
{
	productname = pn;
  barcode = b;
	price = p;
	quantity = q;
}
void Dealer::update()
{
	int id, newquantity, newprice,barcode;
	char productname[25];
	
	cout << "Please enter the id of the product you want to edit:";
	cin >> id;
	cout << "Please enter the new name of the product: ";
	cin.ignore();
	cin.getline(productname, 25);
	cout << "Pleae enter the new quantity of the product:";
	cin >> newquantity;
	cout << "Pleae enter the new per unit price of the product:";
	cin >> newprice;
    barcode= newprice * newquantity;
   
	fstream f("Dealer.txt", ios::in | ios::out);
	
	f.seekp(47 * (id + 2 ) + 3);
	f << left << setw(25) << productname;

	f.seekp(47 * (id  + 2 ) + 28);
	f << left << setw(5) << newquantity;

	f.seekp(47 * (id  + 2 ) + 33);
	f << left << setw(5) << newprice;
	f.seekp(47 * (id + 2) + 38);
	f << left << setw(5) << barcode;


	f.close();

	cout << "Record updated successfully. " << endl;
}

int Dealer::getdata()const
{
  return productname,price,quantity,barcode;	
	
}
Dealer::~Dealer()
{
	
}

Rent::Rent()
{
	productname = ' ';
	elecricitybill = 0;
	shopebill = 0;
	total = 0;
}
int Rent::getFirstBlank()
{
	char data[65];
	ifstream fin("Rent.txt");
	int id = 1;
	while (!fin.eof())
	{
		fin.getline(data, 63);
		if (strncmp(&data[5], "                         ", 25) == 0)
		{
			return id;
		}
		else
		{
			id++;
		}

	}
	fin.close();

}
void Rent::file()
{
	fstream new_file;
	new_file.open("Rent.txt", ios::out);
	if (!new_file)
	{
		cout << "File creation failed";
	}
	else
	{
		new_file << "-------------------------------------------------------     " << endl;
		new_file << "id" << "   Monthname  " << "              Electric" << "  Rent      " << "Total     " << endl;
		new_file << "-------------------------------------------------------     " << endl;
		new_file << "1 " << "   January    " << "              60,000  " << "  10,000    " << "70,000    " << endl;    //Writing to file
		for (int i = 2; i <= 10; i++)
		{
			new_file << left << setw(5) << i;
			new_file << left << setw(25) << "";
			new_file << left << setw(10) << 0;
			new_file << left << setw(10) << 0;
			new_file << left << setw(10) << 0 << endl;
		}
		new_file << "-------------------------------------------------------     " << endl;
		new_file.close();
	}




}
void Rent::add()
{
	int newid = getFirstBlank();

	char productname[26];
	cin.ignore();
	cout << "Please enter the month name:";
	cin.getline(productname, 25);
	cout << "Please enter the elecricitybill:";
	cin >> sto->elecricitybill;
	cout << "Please enter the shopebill :";
	cin >> sto->shopebill;
	total = sto->elecricitybill + sto->shopebill;
	cout << "Total :" << total << endl;
	fstream f("Rent.txt", ios::out | ios::in);
	f.seekp(62 * (newid - 1) + 5);
	f << left << setw(25) << productname;

	f.seekp(62 * (newid - 1) + 30);
	f << left << setw(10) << sto->elecricitybill;

	f.seekp(62 * (newid - 1) + 40);
	f << left << setw(10) << sto->shopebill;
	f.seekp(62 * (newid - 1) + 50);
	f << left << setw(10) << total;

	f.close();


	system("pause");
	system("cls");

}
void Rent::print()
{
	char data[65];
	ifstream fin("Rent.txt");

	while (!fin.eof())
	{
		fin.getline(data, 62);
		if (strncmp(&data[5], "                         ", 25) != 0)
		{
			cout << data << endl;
		}

	}
	fin.close();
}
void Rent::search()
{

	char productname[25];
	cin.ignore();
	cout << "Please enter your search string: ";
	cin.getline(productname, 25);


	char data[65];
	ifstream fin("Rent.txt");
	cout << "-------------------------------------------------------     " << endl;
	cout << "id" << "   Monthname  " << "              Electric" << "  Rent      " << "Total     " << endl;
	cout << "-------------------------------------------------------     " << endl;
	while (!fin.eof())
	{
		fin.getline(data, 62);

		if (strncmp(&data[5], productname, strlen(productname)) == 0)
		{
			cout << data << endl;
		}

	}
	cout << "-------------------------------------------------------     " << endl;
	fin.close();
}
void Rent::setdata(char pn, int sb, int eb, int t)
{
	productname = pn;
	shopebill = sb;
	elecricitybill = eb;
	total = t;

}
int Rent::getdata()const
{
	return productname, shopebill, elecricitybill, total;

}
Rent::~Rent()
{

}

Warhouse::Warhouse()
{
	billid = 0;
	billcustomer = 0;
	billtype = ' ';
}
Warhouse::~Warhouse()
{

}
void Warhouse::setdata(int bi, int bc, char bt)
{

	billid = bi;
	billcustomer = bc;
	billtype = bt;

}
int Warhouse::getdata()const
{
	return billid, billcustomer, billtype;
}
