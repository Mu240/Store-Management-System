#include<iostream>
#include <iomanip>
#include <fstream>
#include<string.h>
#include <conio.h>
#include "inventory.h"
#include <math.h>
//***************************************************************************
//Course: Object Oriented Programming
//Instructor: Aftab Alam
// Code By: Group B
//Main function for test
//***************************************************************************

//NOTE THAT THE FOLLOWING PROGRAM HAS MORE FUNTCTIONALITY THAN REQUIRED.
//THIS IS JUST BECAUSE WE WANTED TO SHOW YOU THAT IF DEFAULT CONSTRUCTOR IS PASSED
//PARAMETERS, IT IS POSSIBLE TO INITIALIZE ITS PRIVATE DATA MEMBERS TO DESIRED VALUES
//***************************************************************************
using namespace std;
int main()
{
	Employee s;
	customer c(new Store());
	Dealer d;
	Store f;
	Rent g;
	Warhouse w;
	char option;
	int ch;
	int op;

	//Password for POS
	//required id is itu and password is store

	cout << "                             <<<<<<<<<< Inventory Store Mangment System >>>>>>>>>>\n" << endl;
	cout<<"                                        ================================           "<<endl;
	string id = "";
	string pass = "";
	char q;
	char l;
	cout << "Enter id: \n";
	l = _getch();
	while (l != 13) {
		id.push_back(l);
		cout << l;
		l = _getch();
	}


	cout << "\nEnter password: \n";
	q = _getch();
	while (q != 13) {
		pass.push_back(q);
		cout << '*';
		q = _getch();
	}

	if (pass == "store" && id == "itu") {

		system("cls");
	}
	else {
		cout << "\nAccess denied...!!!\n";
		return 0;
		system("cls");
	}

	//old file for backup
	cout << "                      -------- Want to create a new file or Work in Old file ----------\n" << endl;
	cout << "\n1.New file\n2.Old file" << endl;
	cout<<"option: "<<endl;
	cin >> op;
	switch (op)
	{
	case 1:
		s.file();
		d.file();
		f.file();
		g.file();
		c.file();

	case 2:
		break;


	}
	system("cls");

    //menu

	do
	{
		cout << "\n\t                  ** MAIN MENU **\n";
		cout << "---------------------------------------------" << endl;
		cout << "1.Class of Employee\n2.Class of Dealer\n3.Class of Store & Customer\n4.Class of Warhouse & Rent";

		cout << "\n5.Exit" << endl;
		cout << "\nEnter your choice: ";
		cout << "\n---------------------------------------------" << endl;
		cout<<"option: "<<endl;
		cin >> ch;

		
		switch (ch)
		{
			//Employee Class
		case 1:
			system("cls");
			while (true)
			{
				cout << "\n                             ^^^^^^^^^^ Employee ^^^^^^^^^^\n" << endl;
				cout << "Please select the option:" << endl;;
				cout << "---------------------------------------------" << endl;
				cout << "A\tAdd new Employee" << endl;
				cout << "P\tPrint all Employee" << endl;
				cout << "S\tSearch Employee" << endl;
				cout << "U\tUpdate Employee" << endl;
				cout << "R\tRemove a Employee" << endl;
				cout << "X\tBack to Main Menu" << endl;
				cout << "---------------------------------------------" << endl;
                cout<<"option: "<<endl;
				cin >> option;
				system("cls");
				if (option == 'a' || option == 'A')
				{
					s.add();
				}
				else if (option == 'p' || option == 'P')
				{
					s.print();
				}

				else if (option == 'r' || option == 'R')
				{
					s.removeemployee();
				}
				else if (option == 's' || option == 'S')
				{
					s.search();
				}
				else if (option == 'u' || option == 'U')
				{
					s.update();
				}
				else if (option == 'x' || option == 'X')
				{
					break;
				}
				else
				{
					cout << "Invlaid input. Try again. " << endl;
				}

				system("pause");
				system("cls");

			}
			break;

			//Dealer Class
		case 2:
			system("cls");
			while (true)
			{
				cout << "\n                             ^^^^^^^^^^ Dealer ^^^^^^^^^^\n" << endl;
				cout << "Please select the option:" << endl;;
				cout << "---------------------------------------------" << endl;
				cout << "A\tAdd new product" << endl;
				cout << "P\tPrint all product" << endl;
				cout << "U\tUpdate product" << endl;
				cout << "X\tBack to Main Menu" << endl;
				cout << "---------------------------------------------" << endl;
                cout<<"option: "<<endl;
				cin >> option;
				system("cls");
				if (option == 'a' || option == 'A')
				{
					d.add();
				}
				else if (option == 'p' || option == 'P')
				{
					d.print();
				}
				else if (option == 'u' || option == 'U')
				{
					d.update();
				}
				else if (option == 'x' || option == 'X')
				{
					break;
				}
				else
				{
					cout << "Invlaid input. Try again. " << endl;
				}
				system("pause");
				system("cls");
			}
			break;

			// Store
		case 3:
			system("cls");
			while (true)
			{
				cout << "\n                             ^^^^^^^^^^ Store ^^^^^^^^^^\n" << endl;
				cout << "Please select the option:" << endl;;
				cout << "---------------------------------------------" << endl;
				cout << "A\tAdd new Product" << endl;
				cout << "P\tPrint all Product" << endl;
				cout << "S\tSearch the Product" << endl;
				cout << "B\tBuy the Product" << endl;
				cout << "U\tUpdate Product" << endl;
				cout << "R\tRemove a Product" << endl;
				cout << "L\tPrint Bill" << endl;
				cout << "X\tBack to Main Menu" << endl;
				cout << "---------------------------------------------" << endl;
				cout<<"option: "<<endl; 
				cin >> option;
				system("cls");
				if (option == 'a' || option == 'A')
				{
					c.addition();
				}
				else if (option == 'p' || option == 'P')
				{
					f.print();
				}
				else if (option == 'b' || option == 'B')
				{
					c.buy();
				}
				else if (option == 'l' || option == 'L')
				{
					cout << "                              ---------- Recipte ----------\n" << endl;
					c.showproduct();
				}
				else if (option == 'r' || option == 'R')
				{
					f.remove();
				}

				else if (option == 'u' || option == 'U')
				{
					f.update();
				}
				else if (option == 's' || option == 'S')
				{
					f.search();
				}
				else if (option == 'x' || option == 'X')
				{
					break;
				}
				else
				{
					cout << "Invlaid input. Try again. " << endl;
				}

				system("pause");
				system("cls");

			}
			break;

			//Warehouse
		case 4:
			system("cls");
			while (true)
			{
				cout << "\n                             ^^^^^^^^^^ Warhouse ^^^^^^^^^^\n" << endl;
				cout << "Please select the option:" << endl;;
				cout << "---------------------------------------------" << endl;
				cout << "A\tAdd new rent in Warhouse" << endl;
				cout << "D\tDispaly Store rent" << endl;
				cout << "H\tDispaly Warhouse" << endl;
				cout << "S\tSearch rent in Warhouse" << endl;
				cout << "X\tBack to Main Menu" << endl;
				cout << "---------------------------------------------" << endl;
                cout<<"option: "<<endl;
				cin >> option;
				system("cls");
				if (option == 'd' || option == 'D')
				{
					cout << "\n                             ^^^^^^^^^^ Store rent ^^^^^^^^^^\n" << endl;
					g.print();
				}
				else if (option == 'h' || option == 'H')
				{
					w.print();
				}
				else if (option == 'a' || option == 'A')
				{
					w.add();

				}
				else if (option == 'a' || option == 'A')
				{
					w.add();

				}
				else if (option == 's' || option == 'S')
				{
					w.search();
				}
				else if (option == 'x' || option == 'X')
				{
					break;
				}
				else
				{
					cout << "Invlaid input. Try again. " << endl;
				}

				system("pause");
				system("cls");

			}
			break;

		case 5:
			break;
		default:
			cout << "Invalid input" << endl;
			system("pause");
			system("cls");
			return 0;
			break;

		}

	} while (ch != 5);
	system("cls");
	cout << "                          =========== Thank you for coming ==========" << endl;
	return 0;
}
